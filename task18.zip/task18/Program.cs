﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace task18
{
    class Program
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Введите строку");
            string stroka = Convert.ToString(Console.ReadLine());
            string[] simvol = new string[stroka.Length];// Формирование архива
            for (int i = 0; i < stroka.Length; i++)
            {
                simvol[i] = Convert.ToString(stroka[i]);//заполнение
            }
            List<string> list = new List<string>();
            list.AddRange(simvol);// Добавление списка в архив               
            for (int i = 0; i < 2; i++)
            {
                if (list[0] == "{" && i == 0)
                {
                    list.RemoveAt(0);
                    for (int a = 0; a < list.Count; a++)
                    {
                        if (list[a] == "}")
                        {
                            i = 5;
                            list.RemoveAt(a);
                        }
                    }
                }
                if (list[0] == "(" && i == 0)
                {
                    list.RemoveAt(0);
                    for (int a = 0; a < list.Count; a++)
                    {
                        if (list[a] == ")")
                        {
                            i = 5;
                            list.RemoveAt(a);
                        }
                    }
                }
                if (list[0] == "[" && i <= 2)
                {
                    list.RemoveAt(0);
                    for (int a = 0; a < list.Count; a++)
                    {
                        if (list[a] == "]")
                        {
                            i = 5;
                            list.RemoveAt(a);
                        }
                    }
                }
                if (i == 5) { i = -1; } else { i = 5; }
            }
            if (list.Count == 0)
            {
                Console.WriteLine("Строка соответствует условию задачи");
            }
            else
            {
                Console.WriteLine("Строка не верна!");
            }
            Console.ReadKey();
        }
    }
}
